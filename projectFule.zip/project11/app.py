from flask import Flask, render_template, request
import os
import csv
from datetime import date

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
CSV_PATH = os.path.join(DATA_DIR, "fuel_prices.csv")

# Default Pakistani sample prices (OGRA style). Update this CSV if you want official numbers.
SAMPLE_CSV = """location,fuel_type,price_per_liter,currency,date
Karachi,Petrol,309.10,PKR,2025-08-16
Karachi,Diesel,272.99,PKR,2025-08-16
Lahore,Petrol,309.10,PKR,2025-08-16
Lahore,Diesel,272.99,PKR,2025-08-16
"""

app = Flask(__name__)

def ensure_csv(path=CSV_PATH):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if not os.path.exists(path):
        with open(path, "w", encoding="utf8", newline="") as f:
            f.write(SAMPLE_CSV)

def load_prices(path=CSV_PATH):
    """Return dict keyed by (location.lower(), fuel_type.lower()) -> price_per_liter (float), currency, date"""
    ensure_csv(path)
    prices = {}
    with open(path, newline='', encoding='utf8') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            key = (row['location'].strip().lower(), row['fuel_type'].strip().lower())
            try:
                price = float(row['price_per_liter'])
            except:
                price = 0.0
            prices[key] = {
                'price_per_liter': price,
                'currency': row.get('currency', 'PKR'),
                'date': row.get('date', str(date.today()))
            }
    return prices

@app.route("/", methods=["GET", "POST"])
def index():
    prices = load_prices()
    # We will show locations present in CSV (unique)
    locations = sorted(set(k[0].title() for k in prices.keys()))
    result = None
    info = None

    if request.method == "POST":
        mode = request.form.get("mode")  # 'money' or 'liters'
        location = request.form.get("location", "").strip()
        fuel = request.form.get("fuel", "").strip()
        amount_text = request.form.get("amount", "").strip()

        key = (location.lower(), fuel.lower())
        info = prices.get(key)
        if not info:
            result = f"No price found for {fuel} in {location}. Please check the CSV in data/fuel_prices.csv"
        else:
            price = float(info['price_per_liter'])  # per liter in PKR for Pakistan
            currency = info['currency']
            # For this app we assume currency is PKR (only Pakistan)
            if currency.upper() != "PKR":
                # If your CSV has non-PKR currency, we simply inform user (app is set to PKR only)
                result = ("This page is set to PKR only. The CSV entry uses currency "
                          f"{currency}. Please update data/fuel_prices.csv to PKR values.")
            else:
                try:
                    amt = float(amount_text)
                    if mode == "money":
                        money = amt
                        # money PKR -> liters = money / price_per_liter (PKR/L)
                        if price <= 0:
                            liters = 0
                        else:
                            liters = money / price
                        result = f"{money:.2f} PKR can buy about {liters:.3f} liters of {fuel} in {location}."
                    else:  # liters -> money
                        liters = amt
                        cost = liters * price
                        result = f"{liters:.3f} L of {fuel} in {location} costs about {cost:.2f} PKR."
                except ValueError:
                    result = "Please enter a valid number for amount."

    # For the form default show Karachi if present
    default_location = "Karachi" if "karachi" in [l.lower() for l in locations] else (locations[0] if locations else "")
    return render_template("index.html",
                           locations=locations,
                           result=result,
                           info=info,
                           default_location=default_location)

if __name__ == "__main__":
    app.run(debug=True, port=7860)
